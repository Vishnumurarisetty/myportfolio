<?php
require('tcpdf/tcpdf.php');

// Create a new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8');

// Set document information
$pdf->SetCreator('Your Name');
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('Your CV');
$pdf->SetSubject('Your CV');
$pdf->SetKeywords('CV, resume');

// Add a page
$pdf->AddPage();

// Your CV content here
$pdf->SetFont('Helvetica', '', 12);
$pdf->MultiCell(0, 10, 'Your CV content goes here...', 0, 'L');

// Output the PDF to the browser
$pdf->Output('vishnudeveloper.pdf', 'D');
?>
